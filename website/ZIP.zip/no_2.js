function validateLoginForm() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
  
    if (username == "" || password == "") {
      alert("Please enter a username and password.");
      return false;
    }
  
    return true;
  }